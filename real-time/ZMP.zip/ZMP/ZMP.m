clc;
clear;

load('joint(1).mat');
load('fsr(1).mat');
LF = LFsrBL+LFsrBR+LFsrFL+LFsrFR;
RF = RFsrBL+RFsrBR+RFsrFL+RFsrFR;
main = sign(LF-RF);
main(47) = 0;
main(48) = 0;

x1 = 70.25;y1 = 29.9;
x2 = 70.25;y2 = -23.1;


x3 = -30.25;y3 = 29.9;
x4 = -29.65;y4 = -19.1;
z = 0;
l1 = 45.19;
l2 = 102.99;
l3 = 100;
l4 = 50;
 axis equal
color = ['r' 'g' 'b' 'c' 'm' 'y' 'k' ];
%%%�������ҽ�����ڻ�������������ϵ������%%%
%%������ת����
Rot_matrix = zeros(4,4,2,1);
for i = 1:100
    theta1 = -LAnklePitch(i);
    theta2 = LAnkleRoll(i);
    theta3 = -LKneePitch(i);
    theta4 = -LHipPitch(i);
    theta5 = LHipRoll(i);
    theta6 = LHipYawPitch(i);
    c1 = [1 0 0 0;0 1 0 0; 0 0 1 l1;0 0 0 1];
    c2 = [cos(theta1) 0 sin(theta1) 0; 0 1 0 0; -sin(theta1) 0 cos(theta1) 0; 0 0 0 1];
    c3 = [1 0 0 0;0 cos(theta2) -sin(theta2) 0; 0 sin(theta2) cos(theta2)  0; 0 0 0 1];
    c4 = [1 0 0 0;0 1 0 0; 0 0 1 l2;0 0 0 1];
    c5 = [cos(theta3) 0 sin(theta3) 0; 0 1 0 0; -sin(theta3) 0 cos(theta3) 0; 0 0 0 1];
    c6 = [1 0 0 0;0 1 0 0; 0 0 1 l3;0 0 0 1];
    c7 = [1 0 0 0;0 cos(theta5) -sin(theta5) 0; 0 sin(theta5) cos(theta5)  0; 0 0 0 1];
    c8 = [cos(theta4) 0 sin(theta4) 0; 0 1 0 0; -sin(theta4) 0 cos(theta4) 0; 0 0 0 1];
    c9 = [1 0 0 0;0 1 0 -l4; 0 0 1 l4;0 0 0 1];
    c10 = [1 0 0 0;0 cos(pi/4) -sin(pi/4) 0; 0 sin(pi/4) cos(pi/4)  0; 0 0 0 1]...
    *[cos(theta6) -sin(theta6) 0 0; sin(theta6) cos(theta6) 0 0; 0 0 1 0; 0 0 0 1]...
    *[1 0 0 0;0 cos(pi/4) sin(pi/4) 0; 0 -sin(pi/4) cos(pi/4)  0; 0 0 0 1];
    Rot_L = c10*c9*c8*c7*c6*c5*c4*c3*c2*c1;
    %���������Żص�������
    Rot_matrix(:,:,1,i) = Rot_L;
    %����ĸ�FSR��λ�þ���
    final_L(1,:,i) = Rot_L*[x1;y1;z;1]; %#ok<SAGROW>
    final_L(2,:,i) = Rot_L*[x2;y2;z;1];%#ok<SAGROW>
    final_L(3,:,i) = Rot_L*[x3;y3;z;1];%#ok<SAGROW>
    final_L(4,:,i) = Rot_L*[x4;y4;z;1];%#ok<SAGROW>
    
    
    theta1 = -RAnklePitch(i);
    theta2 = RAnkleRoll(i);
    theta3 = -RKneePitch(i);
    theta4 = -RHipPitch(i);
    theta5 = RHipRoll(i);      
    theta6 = -RHipYawPitch(i);
    
    c1 = [1 0 0 0;0 1 0 0; 0 0 1 l1;0 0 0 1];
    c2 = [cos(theta1) 0 sin(theta1) 0; 0 1 0 0; -sin(theta1) 0 cos(theta1) 0; 0 0 0 1];
    c3 = [1 0 0 0;0 cos(theta2) -sin(theta2) 0; 0 sin(theta2) cos(theta2)  0; 0 0 0 1];
    c4 = [1 0 0 0;0 1 0 0; 0 0 1 l2;0 0 0 1];
    c5 = [cos(theta3) 0 sin(theta3) 0; 0 1 0 0; -sin(theta3) 0 cos(theta3) 0; 0 0 0 1];
    c6 = [1 0 0 0;0 1 0 0; 0 0 1 l3;0 0 0 1];
    c7 = [1 0 0 0;0 cos(theta5) -sin(theta5) 0; 0 sin(theta5) cos(theta5)  0; 0 0 0 1];
    c8 = [cos(theta4) 0 sin(theta4) 0; 0 1 0 0; -sin(theta4) 0 cos(theta4) 0; 0 0 0 1];      
    c9_R = [1 0 0 0;0 1 0 l4; 0 0 1 l4;0 0 0 1];
    c10_R = [1 0 0 0;0 cos(pi/4) -sin(pi/4) 0; 0 sin(pi/4) cos(pi/4)  0; 0 0 0 1]...
    *[cos(theta6) -sin(theta6) 0 0; sin(theta6) cos(theta6) 0 0; 0 0 1 0; 0 0 0 1]...
    *[1 0 0 0;0 cos(pi/4) sin(pi/4) 0; 0 -sin(pi/4) cos(pi/4)  0; 0 0 0 1];
    %������ת����Ȼ��ŵ������д���
    Rot_R = c10_R*c9_R*c8*c7*c6*c5*c4*c3*c2*c1;
    Rot_matrix(:,:,2,i) = Rot_R;
    %�ҽ��ĸ�FSR��λ�þ���
    final_R(1,:,i) = Rot_R*[x1;y1;z;1]; %#ok<SAGROW>
    final_R(2,:,i) = Rot_R*[x2;y2;z;1];%#ok<SAGROW>
    final_R(3,:,i) = Rot_R*[x3;y3;z;1];%#ok<SAGROW>
    final_R(4,:,i) = Rot_R*[x4;y4;z;1];%#ok<SAGROW>
end

%������ʼ������
 i = 18;
     x = [final_L(1,1,i) final_L(2,1,i) final_L(4,1,i) final_L(3,1,i) final_L(1,1,i)];
     y = [final_L(1,2,i) final_L(2,2,i) final_L(4,2,i) final_L(3,2,i) final_L(1,2,i)];
     z = [final_L(1,3,i) final_L(2,3,i) final_L(4,3,i) final_L(3,3,i) final_L(1,3,i)];
     z = -z;

     plot3(x,y,z,'-*');
     axis([-130 190 -170 150 -300 -250]);
     hold on;
     x = [final_R(1,1,i) final_R(2,1,i) final_R(4,1,i) final_R(3,1,i) final_R(1,1,i)];
     y = [final_R(1,2,i) final_R(2,2,i) final_R(4,2,i) final_R(3,2,i) final_R(1,2,i)];
     z = [final_R(1,3,i) final_R(2,3,i) final_R(4,3,i) final_R(3,3,i) final_R(1,3,i)];
     z = -z;
     plot3(x,y,z,'-*');

%%%������Ҫ�ŵĺ���%%%
%��ʼ������
    main_foot = [final_L(1,:,18)' final_L(2,:,18)' final_L(4,:,18)' final_L(3,:,18)'];
    L_foot(:,:,1) = [final_L(1,:,18)' final_L(2,:,18)' final_L(4,:,18)' final_L(3,:,18)'];
    R_foot(:,:,1) = [final_R(1,:,18)' final_R(2,:,18)' final_R(4,:,18)' final_R(3,:,18)'];
flag = 1;
for i = 19:50       
        if(flag == 1)         
            L_foot(:,:,i) = [final_L(1,:,i)' final_L(2,:,i)' final_L(4,:,i)' final_L(3,:,i)'];
            Rot_3 = (Rot_matrix(:,:,1,i-1))*(Rot_matrix(:,:,1,i)^-1);
            Rot_matrix(:,:,1,i) = Rot_3*Rot_matrix(:,:,1,i);
            Rot_matrix(:,:,2,i) = Rot_3*Rot_matrix(:,:,2,i);
            R_foot(:,:,i) = Rot_3*[final_R(1,:,i)' final_R(2,:,i)' final_R(4,:,i)' final_R(3,:,i)'];
            %L_foot(:,:,i) = [final_L(1,:,i-1)' final_L(2,:,i-1)' final_L(4,:,i-1)' final_L(3,:,i-1)'];%��ʽ����ʹ�����
            L_foot(:,:,i) = Rot_3*[final_L(1,:,i)' final_L(2,:,i)' final_L(4,:,i)' final_L(3,:,i)'];
                x1 = [L_foot(1,:,i) L_foot(1,1,i)];
                y1 = [L_foot(2,:,i) L_foot(2,1,i)];
                z1 = [L_foot(3,:,i) L_foot(3,1,i)];
                z1 = -z1;
                plot3(x1,y1,z1,color(floor(mod(i-1,7)+1)));
                hold on
                
                x1 = [R_foot(1,:,i) R_foot(1,1,i)];
                y1 = [R_foot(2,:,i) R_foot(2,1,i)];
                z1 = [R_foot(3,:,i) R_foot(3,1,i)];
                z1 = -z1;
                plot3(x1,y1,z1,color(floor(mod(i-1,7)+1))); 
                hold on
        elseif(flag == 2)
            R_foot(:,:,i)=[final_R(1,:,i)' final_R(2,:,i)' final_R(4,:,i)' final_R(3,:,i)'];
            Rot_3 = (Rot_matrix(:,:,2,i-1))*(Rot_matrix(:,:,2,i)^-1);
            Rot_matrix(:,:,1,i) = Rot_3*Rot_matrix(:,:,1,i);
            Rot_matrix(:,:,2,i) = Rot_3*Rot_matrix(:,:,2,i);
            R_foot(:,:,i) = Rot_3*[final_R(1,:,i)' final_R(2,:,i)' final_R(4,:,i)' final_R(3,:,i)'];
            %R_foot(:,:,i) = R_foot(:,:,i);%��ʽ����ʹ�����
            L_foot(:,:,i) = Rot_3*[final_L(1,:,i)' final_L(2,:,i)' final_L(4,:,i)' final_L(3,:,i)'];
                x1 = [L_foot(1,:,i) L_foot(1,1,i)];
                y1 = [L_foot(2,:,i) L_foot(2,1,i)];
                z1 = [L_foot(3,:,i) L_foot(3,1,i)];
                z1 = -z1;
                plot3(x1,y1,z1,color(floor(mod(i-1,7)+1)));
                hold on
                
                x1 = [R_foot(1,:,i) R_foot(1,1,i)];
                y1 = [R_foot(2,:,i) R_foot(2,1,i)];
                z1 = [R_foot(3,:,i) R_foot(3,1,i)];
                z1 = -z1;
                plot3(x1,y1,z1,color(floor(mod(i-1,7)+1))); 
                hold on
        end
    if(main(i)>0) 
        flag =1;
    else
        flag =2;
    end
    % ��������ӻ�ZMP
    ZMP(i,:) = (LFsrFL(i)*L_foot(:,1,i) + LFsrFR(i)*L_foot(:,2,i) + LFsrBL(i)*L_foot(:,3,i) + LFsrBR(i)*L_foot(:,4,i) + RFsrFL(i)*R_foot(:,1,i) + RFsrFR(i)*R_foot(:,2,i) + RFsrBL(i)*R_foot(:,3,i) + RFsrBR(i)*R_foot(:,4,i))/(RF(i)+LF(i));
    scatter3(ZMP(i,1), ZMP(i,2),-300);
    hold on
    axis([-100 400 -60 200 -350 -250])
    %axis equal
end

